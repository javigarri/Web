// Diccionario de traducciones para soporte multi-idioma (ES, EN, FR, EU)

const TRANSLATIONS = {
    es: {
        nav: {
            inicio: "Inicio",
            miObra: "Mi Obra",
            sobreMi: "Sobre Mí",
            exposiciones: "Exposiciones",
            contacto: "Contacto",
            studio: "Estudio de Arte"
        },
        welcome: {
            tag: "Presentación",
            title: "Bienvenid@s a mi espacio",
            desc: "El objetivo de esta web es ofrecer un recorrido por mis creaciones. Una colección de caras, algunas conocidas y otras anónimas, pero todas llenas de historias que contar, las cuales he tratado de plasmar en mis cuadros. Espero que os transmitan todas esas emociones y experiencias.",
            footer: "¡Disfrutad del viaje…!"
        },
        slider: {
            tag: "Obra Destacada",
            tagNew: "Novedad",
            tagSelected: "Obra Seleccionada",
            tagExclusive: "Colección Exclusiva",
            explore: "Explorar Obra",
            hoverTip: "Ver Detalle"
        },
        miObra: {
            subtitle: "Galería",
            title: "Mi Obra",
            filterAll: "Todos",
            filterOleo: "Óleos",
            filterAcrilico: "Acrílicos",
            filterMixta: "Técnica Mixta"
        },
        sobreMi: {
            subtitle: "Trayectoria",
            title: "Sobre Mí",
            quote: "«Si pudieras decirlo con palabras, no habría razón para pintarlo.»",
            quoteAuthor: "Edward Hopper",
            p1: "Mi nombre es Javi. Nací en Vitoria-Gasteiz en 1963, aunque pasé mi infancia en Apellániz, donde vivía toda mi familia.",
            p2: "Una vez finalizados mis estudios, me trasladé a Valencia donde residí tres años. Durante aquella estancia se despertó en mí el interés por el arte, ya que conocí de cerca el trabajo de Paco Sena, pintor amateur cuya obra estaba inspirada en Sorolla.",
            p3: "Al regresar a Vitoria, trabajé durante veinte años en la industria aeronáutica. En 2010 me desplacé a Monaghan (Irlanda), donde viví un año. Allí cooperé en «Solas Drop-in Centre», un centro de acogida a personas en riesgo de exclusión social. Fue en esa etapa cuando empezó mi andadura en el mundo de la pintura. En aquel nuevo entorno, los sentimientos y las emociones que me rodeaban fueron la inspiración para mis primeros bocetos.",
            p4: "Después de un tiempo alejado del arte, me reencontré con aquello que me sirvió hace unos años para evadirme, la pintura. Esta web es un reflejo de todo aquello que he ido aprendiendo y creando.",
            signature: "Espero que os guste…"
        },
        exposiciones: {
            subtitle: "Agenda",
            title: "Exposiciones",
            statusCurrent: "Vigente",
            statusUpcoming: "Próxima",
            statusPast: "Pasada",
            expo1Title: "Luz y Silencio",
            expo1Venue: "Galería Vanguardia, Madrid",
            expo1Months: "Mayo - Julio",
            expo1Desc: "Una muestra individual que reúne las últimas pinturas abstractas de gran formato. Las obras giran en torno a la dualidad cromática del blanco de titanio y el negro de humo, explorando el silencio visual.",
            expo2Title: "Texturas del Alma",
            expo2Venue: "Centro de Arte Contemporáneo, Barcelona",
            expo2Months: "Noviembre",
            expo2Desc: "Exhibición colectiva que explora el uso del volumen y los relieves en la pintura española contemporánea. Se expondrán piezas clave de la colección 'Guardián del Norte'.",
            expo3Title: "Horizontes Abstractos",
            expo3Venue: "Galería Bauhaus, Berlín",
            expo3Months: "Septiembre",
            expo3Desc: "Una retrospectiva de trabajos en técnica mixta realizados entre 2021 y 2024, con especial enfoque en el diálogo entre geometrías rectas y manchas orgánicas libres."
        },
        contacto: {
            subtitle: "Conversaciones",
            title: "Contacto",
            desc: "Si deseas adquirir una de las obras, programar una visita privada a mi taller en Madrid, o discutir una comisión a medida, por favor escríbeme. Estaré encantado de recibirte.",
            labelAddress: "Taller / Dirección",
            labelEmail: "Email",
            labelPhone: "Teléfono",
            formName: "Nombre Completo",
            formEmail: "Correo Electrónico",
            formSubject: "Asunto (Ej: Interés en obra o visita)",
            formMessage: "Mensaje",
            formBtn: "Enviar Mensaje",
            formSuccess: "¡Gracias, {name}! Tu mensaje ha sido enviado correctamente. Responderé lo antes posible.",
            formError: "Por favor, rellena todos los campos requeridos.",
            formSending: "Enviando..."
        },
        lightbox: {
            year: "Año",
            tech: "Técnica",
            size: "Dimensiones",
            status: "Estado",
            available: "Disponible",
            privateCol: "Colección Privada",
            btnInquire: "Consultar disponibilidad",
            btnPrev: "← Anterior",
            btnNext: "Siguiente →",
            inquireSubject: "Consulta de obra: \"{title}\"",
            inquireMessage: "Hola, estoy interesado/a en conocer más detalles (precios, visitas) sobre el cuadro \"{title}\" ({year}, {tech}, {size}). Quedo a la espera."
        },
        paintings: {
            "painting-0": {
                title: "Reflejos del Alma",
                tech: "Óleo sobre lienzo",
                desc: "Una obra íntima que explora las profundidades de la introspección humana mediante veladuras superpuestas de azul cobalto, siena tostada y oro. Las pinceladas cargadas representan el estrato de las vivencias del alma."
            },
            "painting-1": {
                title: "Geometría del Caos",
                tech: "Acrílico y texturas sobre tabla",
                desc: "Esta pintura presenta una audaz intersección de planos geométricos y texturas densas creadas con pasta de mármol. Simboliza la búsqueda constante de equilibrio y estructura frente al aparente desorden de la existencia."
            },
            "painting-2": {
                title: "Silueta en la Niebla",
                tech: "Técnica mixta sobre lienzo",
                desc: "La fusión de grafito, carboncillo, acrílico y finas capas de pintura al óleo diluida crea una atmósfera enigmática. Sugiere la transitoriedad y la belleza melancólica de los recuerdos desvanecidos por el tiempo."
            },
            "painting-3": {
                title: "Susurros Urbanos",
                tech: "Óleo con espátula sobre lienzo",
                desc: "Trabajada íntegramente con espátulas metálicas, esta obra captura la energía y los contrastes cromáticos de la vida urbana. Capas gruesas de óleo crean una topografía de colores intensos y contrastados."
            },
            "painting-4": {
                title: "Horizonte Perdido",
                tech: "Óleo sobre lino",
                desc: "Un ejercicio minimalista de contemplación marina. La extrema sutileza cromática evoca el amanecer de una costa brumosa, donde el cielo y el océano se funden en una sola y serena vibración visual."
            },
            "painting-5": {
                title: "Atardecer Abstracto",
                tech: "Acrílico sobre lienzo",
                desc: "Una explosión de rojos, ocres y violetas que abstraen el fenómeno de la luz en el ocaso. Las pinceladas gestuales libres aportan un ritmo dinámico y apasionado a la composición general."
            },
            "painting-6": {
                title: "El Guardián del Norte",
                tech: "Técnica mixta y pan de oro",
                desc: "Una pieza inspirada en el norte, la soledad y la comunión con la naturaleza hostil. La textura rugosa de arena e hilo en el lienzo contrasta con la finura brillante del pan de oro de 22K que resalta los puntos de luz."
            }
        }
    },
    en: {
        nav: {
            inicio: "Home",
            miObra: "My Work",
            sobreMi: "About Me",
            exposiciones: "Exhibitions",
            contacto: "Contact",
            studio: "Art Studio"
        },
        welcome: {
            tag: "Introduction",
            title: "Welcome to my space",
            desc: "The purpose of this website is to offer a journey through my creations. A collection of faces, some familiar and others anonymous, but all full of stories to tell, which I have tried to express in my paintings. I hope they convey all these emotions and experiences to you.",
            footer: "Enjoy the journey…!"
        },
        slider: {
            tag: "Featured Work",
            tagNew: "New Release",
            tagSelected: "Selected Work",
            tagExclusive: "Exclusive Collection",
            explore: "Explore Work",
            hoverTip: "View Details"
        },
        miObra: {
            subtitle: "Gallery",
            title: "My Work",
            filterAll: "All",
            filterOleo: "Oils",
            filterAcrilico: "Acrylics",
            filterMixta: "Mixed Media"
        },
        sobreMi: {
            subtitle: "Career",
            title: "About Me",
            quote: "«If you could say it in words, there would be no reason to paint it.»",
            quoteAuthor: "Edward Hopper",
            p1: "My name is Javi. I was born in Vitoria-Gasteiz in 1963, although I spent my childhood in Apellániz, where all my family lived.",
            p2: "Once my studies were completed, I moved to Valencia where I lived for three years. During that stay my interest in art was awakened, as I got to know first-hand the work of Paco Sena, an amateur painter whose work was inspired by Sorolla.",
            p3: "Upon returning to Vitoria, I worked for twenty years in the aeronautical industry. In 2010 I moved to Monaghan (Ireland), where I lived for a year. There I cooperated at 'Solas Drop-in Centre', a shelter for people at risk of social exclusion. It was during this stage that my journey in the world of painting began. In that new environment, the feelings and emotions that surrounded me were the inspiration for my first sketches.",
            p4: "After some time away from art, I reunited with what had served me a few years ago to escape, painting. This website is a reflection of all that I have learned and created.",
            signature: "Hope you like it…"
        },
        exposiciones: {
            subtitle: "Schedule",
            title: "Exhibitions",
            statusCurrent: "Current",
            statusUpcoming: "Upcoming",
            statusPast: "Past",
            expo1Title: "Light and Silence",
            expo1Venue: "Vanguardia Gallery, Madrid",
            expo1Months: "May - July",
            expo1Desc: "A solo exhibition bringing together the latest large-format abstract paintings. The works revolve around the chromatic duality of titanium white and lamp black, exploring visual silence.",
            expo2Title: "Textures of the Soul",
            expo2Venue: "Contemporary Art Centre, Barcelona",
            expo2Months: "November",
            expo2Desc: "Group exhibition exploring the use of volume and reliefs in contemporary Spanish painting. Key pieces from the 'Guardian of the North' collection will be on display.",
            expo3Title: "Abstract Horizons",
            expo3Venue: "Bauhaus Gallery, Berlin",
            expo3Months: "September",
            expo3Desc: "A retrospective of mixed media works created between 2021 and 2024, with a special focus on the dialogue between straight geometries and free organic spots."
        },
        contacto: {
            subtitle: "Conversations",
            title: "Contact",
            desc: "If you wish to purchase one of the works, schedule a private visit to my studio in Madrid, or discuss a custom commission, please write to me. I will be delighted to welcome you.",
            labelAddress: "Studio / Address",
            labelEmail: "Email",
            labelPhone: "Phone",
            formName: "Full Name",
            formEmail: "Email Address",
            formSubject: "Subject (e.g. Interest in work or visit)",
            formMessage: "Message",
            formBtn: "Send Message",
            formSuccess: "Thank you, {name}! Your message has been sent successfully. I will reply as soon as possible.",
            formError: "Please fill in all required fields.",
            formSending: "Sending..."
        },
        lightbox: {
            year: "Year",
            tech: "Technique",
            size: "Dimensions",
            status: "Status",
            available: "Available",
            privateCol: "Private Collection",
            btnInquire: "Inquire availability",
            btnPrev: "← Previous",
            btnNext: "Next →",
            inquireSubject: "Inquiry about work: \"{title}\"",
            inquireMessage: "Hello, I am interested in knowing more details (pricing, visits) about the painting \"{title}\" ({year}, {tech}, {size}). Looking forward to your reply."
        },
        paintings: {
            "painting-0": {
                title: "Reflections of the Soul",
                tech: "Oil on canvas",
                desc: "An intimate work that explores the depths of human introspection through superimposed glazes of cobalt blue, burnt sienna, and gold. The heavy brushstrokes represent the layers of life's experiences."
            },
            "painting-1": {
                title: "Geometry of Chaos",
                tech: "Acrylic and textures on wood",
                desc: "This painting presents a bold intersection of geometric planes and dense textures created with marble paste. It symbolizes the constant search for balance and structure against the apparent disorder of existence."
            },
            "painting-2": {
                title: "Silhouette in the Fog",
                tech: "Mixed media on canvas",
                desc: "The fusion of graphite, charcoal, acrylic, and thin layers of diluted oil paint creates an enigmatic atmosphere. It suggests the transience and melancholic beauty of memories faded by time."
            },
            "painting-3": {
                title: "Urban Whispers",
                tech: "Oil with palette knife on canvas",
                desc: "Worked entirely with metal palette knives, this piece captures the energy and chromatic contrasts of urban life. Thick layers of oil paint create a topography of intense and contrasting colors."
            },
            "painting-4": {
                title: "Lost Horizon",
                tech: "Oil on linen",
                desc: "A minimalist exercise in marine contemplation. The extreme chromatic subtlety evokes the dawn of a misty coast, where the sky and the ocean merge in a single, serene visual vibration."
            },
            "painting-5": {
                title: "Abstract Sunset",
                tech: "Acrylic on canvas",
                desc: "An explosion of reds, ochres, and purples abstracting the light during twilight. The free gestural brushstrokes bring a dynamic and passionate rhythm to the overall composition."
            },
            "painting-6": {
                title: "The Guardian of the North",
                tech: "Mixed media and gold leaf",
                desc: "A piece inspired by the far north, solitude, and communion with a hostile nature. The rough texture of sand and thread on the canvas contrasts with the brilliant refinement of the 22K gold leaf."
            }
        }
    },
    fr: {
        nav: {
            inicio: "Accueil",
            miObra: "Mon Œuvre",
            sobreMi: "À Propos",
            exposiciones: "Expositions",
            contacto: "Contact",
            studio: "Atelier d'Art"
        },
        welcome: {
            tag: "Présentation",
            title: "Bienvenue dans mon espace",
            desc: "L'objectif de ce site est de proposer un parcours à travers mes créations. Une collection de visages, certains familiers et d'autres anonymes, mais tous chargés d'histoires à raconter, que j'ai essayé d'exprimer dans mes tableaux. J'espère qu'ils vous transmettront toutes ces émotions et expériences.",
            footer: "Bon voyage…!"
        },
        slider: {
            tag: "Œuvre Vedette",
            tagNew: "Nouveauté",
            tagSelected: "Œuvre Sélectionnée",
            tagExclusive: "Collection Exclusive",
            explore: "Explorer l'Œuvre",
            hoverTip: "Voir Détails"
        },
        miObra: {
            subtitle: "Galerie",
            title: "Mon Œuvre",
            filterAll: "Tous",
            filterOleo: "Huiles",
            filterAcrilico: "Acryliques",
            filterMixta: "Technique Mixte"
        },
        sobreMi: {
            subtitle: "Parcours",
            title: "À Propos de Moi",
            quote: "«Si vous pouviez le dire avec des mots, il n'y aurait aucune raison de le peindre.»",
            quoteAuthor: "Edward Hopper",
            p1: "Je m'appelle Javi. Je suis né à Vitoria-Gasteiz en 1963, bien que j'aie passé mon enfance à Apellániz, où vivait toute ma famille.",
            p2: "Une fois mes études terminées, je me suis installé à Valence où j'ai résidé pendant trois ans. C'est durant ce séjour que s'est éveillé mon intérêt pour l'art, car j'ai découvert de près le travail de Paco Sena, peintre amateur dont l'œuvre s'inspirait de Sorolla.",
            p3: "À mon retour à Vitoria, j'ai travaillé pendant vingt ans dans l'industrie aéronautique. En 2010, je me suis installé à Monaghan (Irlande), où j'ai vécu un an. J'y ai collaboré avec le « Solas Drop-in Centre », un centre d'accueil pour personnes en risque d'exclusion sociale. C'est à cette époque que mon parcours dans le monde de la peinture a débuté. Dans ce nouvel environnement, les sentiments et les émotions qui m'entouraient ont été l'inspiration de mes premières esquisses.",
            p4: "Après avoir passé quelque temps loin de l'art, j'ai renoué avec ce qui m'avait servi quelques années auparavant à m'évader : la peinture. Ce site est le reflet de tout ce que j'ai appris et créé.",
            signature: "J'espère que vous l'aimerez…"
        },
        exposiciones: {
            subtitle: "Agenda",
            title: "Expositions",
            statusCurrent: "En Cours",
            statusUpcoming: "À Venir",
            statusPast: "Passée",
            expo1Title: "Lumière et Silence",
            expo1Venue: "Galerie Vanguardia, Madrid",
            expo1Months: "Mai - Juillet",
            expo1Desc: "Une exposition personnelle réunissant les dernières peintures abstraites de grand format. Les œuvres tournent autour de la dualité chromatique du blanc de titane et du noir de fumée, explorant le silence visuel.",
            expo2Title: "Textures de l'Âme",
            expo2Venue: "Centre d'Art Contemporain, Barcelone",
            expo2Months: "Novembre",
            expo2Desc: "Exposition collective explorant l'utilisation du volume et des reliefs dans la peinture espagnole contemporaine. Des pièces clés de la collection « Le Gardien du Nord » seront exposées.",
            expo3Title: "Horizons Abstraits",
            expo3Venue: "Galerie Bauhaus, Berlin",
            expo3Months: "Septembre",
            expo3Desc: "Une rétrospective d'œuvres en techniques mixtes réalisées entre 2021 et 2024, avec un accent particulier sur le dialogue entre géométries droites et taches organiques libres."
        },
        contacto: {
            subtitle: "Conversations",
            title: "Contact",
            desc: "Si vous souhaitez acquérir l'une des œuvres, planifier une visite privée de mon atelier à Madrid ou discuter d'une commande sur mesure, n'hésitez pas à m'écrire. Je serai ravi de vous accueillir.",
            labelAddress: "Atelier / Adresse",
            labelEmail: "Email",
            labelPhone: "Téléphone",
            formName: "Nom Complet",
            formEmail: "Adresse E-mail",
            formSubject: "Objet (Ex: Intérêt pour une œuvre o visite)",
            formMessage: "Message",
            formBtn: "Envoyer le message",
            formSuccess: "Merci, {name}! Votre message a été envoyé avec succès. Je répondrai dès que possible.",
            formError: "Veuillez remplir tous les champs obligatoires.",
            formSending: "Envoi en cours..."
        },
        lightbox: {
            year: "Année",
            tech: "Technique",
            size: "Dimensions",
            status: "Statut",
            available: "Disponible",
            privateCol: "Collection Privée",
            btnInquire: "Consulter la disponibilité",
            btnPrev: "← Précédent",
            btnNext: "Suivant →",
            inquireSubject: "Demande d'information: \"{title}\"",
            inquireMessage: "Bonjour, je serais intéressé(e) d'en savoir plus (prix, visites) sur le tableau \"{title}\" ({year}, {tech}, {size}). Dans l'attente de votre réponse."
        },
        paintings: {
            "painting-0": {
                title: "Reflets de l'Âme",
                tech: "Huile sur toile",
                desc: "Une œuvre intime explorant les profondeurs de l'introspection humaine à travers des couches superposées de bleu cobalt, de terre de Sienne brûlée et d'or. Les coups de pinceau denses représentent les couches de l'expérience de la vie."
            },
            "painting-1": {
                title: "Géométrie du Chaos",
                tech: "Acrylique et textures sur panneau",
                desc: "Cette peinture présente une intersection audacieuse de plans géométriques et de textures épaisses créées avec de la pâte de marbre. Elle symbolise la recherche constante de l'ordre face au désordre apparent de la vie."
            },
            "painting-2": {
                title: "Silhouette dans la Brume",
                tech: "Technique mixte sur toile",
                desc: "La fusion du graphite, du fusain, de l'acrylique et de fines couches de peinture à l'huile diluée crée une atmosphère énigmatique. Elle suggère le caractère éphémère et la beauté mélancolique des souvenirs effacés par le temps."
            },
            "painting-3": {
                title: "Murmures Urbains",
                tech: "Huile au couteau sur toile",
                desc: "Travaillée entièrement au couteau, cette œuvre capte l'énergie et les contrastes de couleurs de la vie urbaine. Les épaisses couches de peinture créent une véritable topographie de teintes vives."
            },
            "painting-4": {
                title: "Horizon Perdu",
                tech: "Huile sur lin",
                desc: "Un exercice minimaliste de contemplation marine. La subtilité des couleurs évoque l'aube sur une côte brumeuse, où le ciel et l'océan se fondent dans une même vibration visuelle sereine."
            },
            "painting-5": {
                title: "Coucher de Soleil Abstrait",
                tech: "Acrylique sur toile",
                desc: "Une explosion de rouges, d'ocres et de violets qui capture la lumière éphémère du crépuscule. Les coups de pinceau dynamiques et libres confèrent un rythme passionné à la composition."
            },
            "painting-6": {
                title: "Le Gardien du Nord",
                tech: "Technique mixte et feuille d'or",
                desc: "Une pièce inspirée par le Grand Nord, la solitude et la communion avec une nature sauvage. La texture rugueuse du sable sur la toile contraste avec l'éclat délicat de la feuille d'or 22 carats."
            }
        }
    },
    eu: {
        nav: {
            inicio: "Hasiera",
            miObra: "Nire Lana",
            sobreMi: "Niri Buruz",
            exposiciones: "Erakusketak",
            contacto: "Kontaktua",
            studio: "Arte Lantegia"
        },
        welcome: {
            tag: "Aurkezpena",
            title: "Ongi etorri nire gunera",
            desc: "Webgune honen helburua nire sorkuntzetan zehar ibilbide bat eskaintzea da. Aurpegien bilduma bat, batzuk ezagunak eta beste batzuk anonimoak, baina guztiak kontatzeko istorioz beteak, nire margolanetan islatzen ahalegindu naizenak. Sentimendu eta esperientzia horiek guztiak helaraziko dizkizuelakoan nago.",
            footer: "Gozatu bidaiaz…!"
        },
        slider: {
            tag: "Obra Nabarmentzailea",
            tagNew: "Berria",
            tagSelected: "Hautatutako Obra",
            tagExclusive: "Bilduma Esklusiboa",
            explore: "Ikusi Margolana",
            hoverTip: "Ikusi Xehetasuna"
        },
        miObra: {
            subtitle: "Galeria",
            title: "Nire Lana",
            filterAll: "Denak",
            filterOleo: "Olio-pinturak",
            filterAcrilico: "Akrilikoak",
            filterMixta: "Teknika Mistoa"
        },
        sobreMi: {
            subtitle: "Ibilbidea",
            title: "Niri Buruz",
            quote: "«Hitzekin esan ahal bazenu, ez zatekeen margotzeko arrazoirik egongo.»",
            quoteAuthor: "Edward Hopper",
            p1: "Javi dut izena. Gasteizen jaio nintzen 1963an, nahiz eta haurtzaroa Apilaizen igaro nuen, nire familia guztia bizi zen lekuan.",
            p2: "Ikasketak amaitu ondoren, Valentziara joan nintzen eta hiru urtez bizi izan nintzen bertan. Egonaldi hartan piztu zitzaidan artearekiko interesa, gertutik ezagutu bainuen Paco Senaren lana, bere obra Sorollarengan inspiratua zuen margolari amateurra.",
            p3: "Gasteizera itzultzean, hogei urtez egin nuen lan aeronautikaren industrian. 2010ean Monaghanera (Irlanda) joan nintzen urtebetez bizitzera. Han, gizarte-bazterkeriako arriskuan zeuden pertsonei harrera egiteko «Solas Drop-in Centre» zentroan lagundu nuen. Garai hartan hasi nintzen margolaritzaren munduan. Ingurune berri hartan, nire inguruko sentimenduak eta emozioak izan ziren nire lehen zirriborroetarako inspirazio-iturri.",
            p4: "Artetik denbora batez urrun egon ondoren, duela urte batzuk ihes egiteko balio izan zidan horrekin topo egin nuen berriro: margolaritzarekin. Webgune hau ikasten eta sortzen joan naizen guztiari buruzko hausnarketa da.",
            signature: "Zuen gustukoa izatea espero dut…"
        },
        exposiciones: {
            subtitle: "Egutegia",
            title: "Erakusketak",
            statusCurrent: "Indarrean",
            statusUpcoming: "Hurrengoa",
            statusPast: "Iraganekoa",
            expo1Title: "Argia eta Isiltasuna",
            expo1Venue: "Vanguardia Galeria, Madril",
            expo1Months: "Maiatza - Uztaila",
            expo1Desc: "Formatu handiko azken margolan abstraktuak biltzen dituen bakarkako erakusketa. Obrak titanio zuriaren eta ke beltzaren arteko dualtasun kromatikoaren ingurukoak dira, isiltasun bisuala aztertuz.",
            expo2Title: "Arimaren Testurak",
            expo2Venue: "Arte Garaikideko Zentroa, Bartzelona",
            expo2Months: "Azaroa",
            expo2Desc: "Egungo espainiar margolaritzan bolumenaren eta erliebeen erabilera aztertzen duen erakusketa kolektiboa. 'Iparraldeko Zaindaria' bildumako pieza nagusiak egongo dira ikusgai.",
            expo3Title: "Horizonte Abstraktuak",
            expo3Venue: "Bauhaus Galeria, Berlin",
            expo3Months: "Iraila",
            expo3Desc: "2021 eta 2024 artean teknika mistoan egindako lanen atzerabegirakoa, geometria zuzenen eta orban organiko libreen arteko elkarrizketan arreta berezia jarriz."
        },
        contacto: {
            subtitle: "Elkarrizketak",
            title: "Kontaktua",
            desc: "Margolanen bat erosi nahi baduzu, Madrilgo nire tailerrera bisita pribatu bat antolatu nahi baduzu, edo enkarguzko lan bat adostu nahi baduzu, idatz iezadazu. Pozik hartuko zaitut.",
            labelAddress: "Lantegia / Helbidea",
            labelEmail: "Emaila",
            labelPhone: "Telefonoa",
            formName: "Izen-abizenak",
            formEmail: "Posta elektronikoa",
            formSubject: "Gaia (Adib: Lanarekiko interesa edo bisita)",
            formMessage: "Mezua",
            formBtn: "Mezua Bidali",
            formSuccess: "Eskerrik asko, {name}! Zure mezua ondo bidali da. Ahalik eta azkarren erantzungo dizut.",
            formError: "Mesedez, bete eskatutako eremu guztiak.",
            formSending: "Bidaltzen..."
        },
        lightbox: {
            year: "Urtea",
            tech: "Teknika",
            size: "Neurriak",
            status: "Egoera",
            available: "Eskuragarri",
            privateCol: "Bilduma Pribatua",
            btnInquire: "Galdetu eskuragarritasunaz",
            btnPrev: "← Aurrekoa",
            btnNext: "Hurrengoa →",
            inquireSubject: "Lanari buruzko galdera: \"{title}\"",
            inquireMessage: "Kaixo, interesatuta nago \"{title}\" ({year}, {tech}, {size}) margolanari buruzko xehetasun gehiago (prezioak, bisitak) jakiteko. Erantzunaren zain geratzen naiz."
        },
        paintings: {
            "painting-0": {
                title: "Arimaren Ispiluak",
                tech: "Olio-pintura oihal gainean",
                desc: "Gizakiaren barne-hausnarketaren sakontasuna aztertzen duen obra sakona, kobalto urdin, siena erre eta urrezko geruza gainjarrien bidez. Pincelada sendoek bizitzako esperientzien geruzak irudikatzen dituzte."
            },
            "painting-1": {
                title: "Kaosaren Geometria",
                tech: "Akrilikoa eta testurak taula gainean",
                desc: "Margolan honek plano geometrikoen eta marmol orearekin sortutako testura trinkoen arteko elkargune ausarta erakusten du. Izatearen nahaspilaren aurrean oreka eta egitura bilatzea irudikatzen du."
            },
            "painting-2": {
                title: "Silueta Lainopean",
                tech: "Teknika mistoa oihal gainean",
                desc: "Grafiloaren, egur-ikatza, akrilikoaren eta olio-pintura diluituaren geruza finen batzeak atmosfera enigmatikoa sortzen du. Denborak lausotutako oroitzapenen iragankortasuna eta edertasun melankolikoa iradokitzen du."
            },
            "painting-3": {
                title: "Hiri-xuxurlak",
                tech: "Olioa espatularekin oihal gainean",
                desc: "Espatula metalikoekin osorik landua, lan honek hiri-bizitzaren indarra eta kolore-kontrasteak jasotzen ditu. Olio geruza lodiek kolore bizien topografia bat sortzen dute."
            },
            "painting-4": {
                title: "Horizonte Galdua",
                tech: "Olio-pintura liho gainean",
                desc: "Itsasoaren kontenplaziorako ariketa minimalista bat. Kolore-sutiltasun handiak kostalde lainotsu bateko egunsentia gogorarazten du, non zeruak eta ozeanoak bat egiten duten ikus-bibrazio lasai batean."
            },
            "painting-5": {
                title: "Ilunabar Abstraktua",
                tech: "Akrilikoa oihal gainean",
                desc: "Ilunabarreko argiaren fenomenoa laburbiltzen duen gorrien, okreen eta bioleten leherketa. Pincelada gestual libreek erritmo dinamiko eta sutsua ematen diote konposizioari."
            },
            "painting-6": {
                title: "Iparraldeko Zaindaria",
                tech: "Teknika mistoa eta urrezko hostoa",
                desc: "Iparraldean, bakardadean eta natura etsai batekin bat egitean inspiratutako pieza. Harearen eta hariaren testura zakarrak 22K-ko urrezko hostoaren distira dotorearekin kontrastatzen du."
            }
        }
    }
};
