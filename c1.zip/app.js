// Lógica de la aplicación web - Portfolio de Pintor con Soporte Multi-Idioma

// Base de datos estática de las obras de arte (rutas y dimensiones)
const PAINTINGS_DATA = [
    {
        id: "painting-0",
        image: "cuadros/003-2.webp",
        category: "oleo",
        year: "2024",
        size: "120 x 100 cm",
        status: "Disponible"
    },
    {
        id: "painting-1",
        image: "cuadros/013.webp",
        category: "acrilico",
        year: "2025",
        size: "150 x 150 cm",
        status: "Colección Privada"
    },
    {
        id: "painting-2",
        image: "cuadros/aa-che-1.webp",
        category: "mixta",
        year: "2023",
        size: "100 x 80 cm",
        status: "Disponible"
    },
    {
        id: "painting-3",
        image: "cuadros/aa-shallow-4.webp",
        category: "oleo",
        year: "2024",
        size: "90 x 120 cm",
        status: "Disponible"
    },
    {
        id: "painting-4",
        image: "cuadros/img_20210312_181644-1.webp",
        category: "oleo",
        year: "2021",
        size: "140 x 110 cm",
        status: "Colección Privada"
    },
    {
        id: "painting-5",
        image: "cuadros/img_20251027_164412.webp",
        category: "acrilico",
        year: "2025",
        size: "110 x 90 cm",
        status: "Disponible"
    },
    {
        id: "painting-6",
        image: "cuadros/olenevod.webp",
        category: "mixta",
        year: "2023",
        size: "130 x 100 cm",
        status: "Disponible"
    }
];

// Estado global de la aplicación
const state = {
    activeSection: 'inicio',
    currentSlide: 0,
    slideInterval: null,
    currentLightboxId: null,
    filteredPaintings: [...PAINTINGS_DATA],
    currentLang: 'es'
};

// --- INICIALIZACIÓN ---
document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initLanguageSwitcher();
    initSlider();
    initGalleryFilters();
    initLightbox();
    initContactForm();
    handleHashNavigation();
    
    // Iniciar con el idioma por defecto (Español)
    setLanguage('es');
});

// --- SISTEMA DE TRADUCCIÓN ---
function getNestedValue(obj, keyPath) {
    return keyPath.split('.').reduce((prev, curr) => prev ? prev[curr] : null, obj);
}

function initLanguageSwitcher() {
    const langButtons = document.querySelectorAll('.lang-btn');
    langButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const lang = btn.getAttribute('data-lang');
            setLanguage(lang);
        });
    });
}

function setLanguage(lang) {
    if (!TRANSLATIONS[lang]) return;
    state.currentLang = lang;

    // Actualizar botones de idiomas
    const langButtons = document.querySelectorAll('.lang-btn');
    langButtons.forEach(btn => {
        if (btn.getAttribute('data-lang') === lang) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    // Cambiar atributo lang del HTML
    document.documentElement.lang = lang;

    // Traducir todos los elementos con data-i18n
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(el => {
        const key = el.getAttribute('data-i18n');
        const value = getNestedValue(TRANSLATIONS[lang], key);
        if (value) {
            el.textContent = value;
        }
    });

    // Re-renderizar la galería con los textos traducidos
    renderGallery();

    // Actualizar Lightbox si está abierto
    if (state.currentLightboxId) {
        updateLightboxTexts(state.currentLightboxId);
    }
}

// --- SISTEMA DE NAVEGACIÓN (SPA) ---
function initNavigation() {
    const navLinks = document.querySelectorAll('[data-target]');
    const sidebar = document.getElementById('app-sidebar');
    const menuToggle = document.getElementById('mobile-menu-toggle');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('data-target');
            navigateToSection(targetId);

            // Cerrar menú móvil al navegar
            if (sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
                menuToggle.classList.remove('active');
            }
        });
    });

    // Menú móvil hamburguesa
    menuToggle.addEventListener('click', () => {
        menuToggle.classList.toggle('active');
        sidebar.classList.toggle('active');
    });
}

function navigateToSection(sectionId) {
    const currentSection = document.getElementById(state.activeSection);
    const targetSection = document.getElementById(sectionId);

    if (!targetSection || state.activeSection === sectionId) return;

    // Desactivar sección actual
    if (currentSection) {
        currentSection.classList.remove('active');
    }

    // Activar sección destino
    targetSection.classList.add('active');
    state.activeSection = sectionId;

    // Actualizar enlaces de navegación activos
    const navLinks = document.querySelectorAll('.nav-menu a');
    navLinks.forEach(link => {
        if (link.getAttribute('data-target') === sectionId) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });

    // Actualizar Hash de URL sin disparar scroll
    history.pushState(null, null, `#${sectionId}`);

    // Si salimos de inicio, pausamos slider. Si entramos, iniciamos.
    if (sectionId === 'inicio') {
        startSliderAutoPlay();
    } else {
        stopSliderAutoPlay();
    }

    // Scroll al principio al cambiar de sección
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function handleHashNavigation() {
    const hash = window.location.hash.substring(1);
    if (hash && document.getElementById(hash)) {
        navigateToSection(hash);
    }
}

window.addEventListener('hashchange', () => {
    const hash = window.location.hash.substring(1);
    if (hash && state.activeSection !== hash) {
        navigateToSection(hash);
    }
});

// --- LÓGICA DEL CARRUSEL / BANNER DE INICIO ---
function initSlider() {
    const slides = document.querySelectorAll('.slide');
    const dotsContainer = document.getElementById('slider-dots-container');
    const nextBtn = document.getElementById('next-slide');
    const prevBtn = document.getElementById('prev-slide');

    // Configurar click en los indicadores (dots)
    const dots = dotsContainer.querySelectorAll('.slider-dot');
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            goToSlide(index);
        });
    });

    // Flechas del carrusel
    nextBtn.addEventListener('click', () => {
        nextSlide();
    });
    prevBtn.addEventListener('click', () => {
        prevSlide();
    });

    // Configurar clics en los elementos del banner para llevar a la obra
    const interactiveElements = document.querySelectorAll('[data-target-painting]');
    interactiveElements.forEach(element => {
        element.addEventListener('click', () => {
            const paintingId = element.getAttribute('data-target-painting');
            redirectToPaintingDetails(paintingId);
        });
    });

    // Iniciar autoplay
    startSliderAutoPlay();
}

function startSliderAutoPlay() {
    stopSliderAutoPlay(); // Asegurar de no solapar intervalos
    state.slideInterval = setInterval(() => {
        nextSlide();
    }, 5000); // 5 segundos
}

function stopSliderAutoPlay() {
    if (state.slideInterval) {
        clearInterval(state.slideInterval);
    }
}

function goToSlide(index) {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.slider-dot');

    if (index >= slides.length) index = 0;
    if (index < 0) index = slides.length - 1;

    slides[state.currentSlide].classList.remove('active');
    dots[state.currentSlide].classList.remove('active');

    slides[index].classList.add('active');
    dots[index].classList.add('active');

    state.currentSlide = index;
    startSliderAutoPlay(); // Reiniciar temporizador
}

function nextSlide() {
    goToSlide(state.currentSlide + 1);
}

function prevSlide() {
    goToSlide(state.currentSlide - 1);
}

// Requisito especial: click en banner lleva al cuadro en Mi Obra
function redirectToPaintingDetails(paintingId) {
    // 1. Cambiar a sección Mi Obra
    navigateToSection('mi-obra');
    
    // 2. Esperar que termine la animación de sección y abrir el Lightbox
    setTimeout(() => {
        openLightbox(paintingId);
        
        // Hacer scroll suave hacia el elemento correspondiente de la galería
        const galleryItem = document.querySelector(`[data-id="${paintingId}"]`);
        if (galleryItem) {
            galleryItem.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }, 300);
}

// --- RENDERIZADO Y FILTRO DE GALERÍA (MI OBRA) ---
function renderGallery() {
    const grid = document.getElementById('painting-gallery-grid');
    grid.innerHTML = '';

    const lang = state.currentLang;

    PAINTINGS_DATA.forEach(painting => {
        const translation = TRANSLATIONS[lang].paintings[painting.id];
        const title = translation ? translation.title : "";
        const tech = translation ? translation.tech : "";
        
        const catKey = 'filter' + painting.category.charAt(0).toUpperCase() + painting.category.slice(1);
        const categoryLabel = TRANSLATIONS[lang].miObra[catKey];

        const item = document.createElement('div');
        item.className = 'gallery-item';
        item.setAttribute('data-category', painting.category);
        item.setAttribute('data-id', painting.id);
        
        item.innerHTML = `
            <div class="gallery-item-image">
                <img src="${painting.image}" alt="${title}" loading="lazy">
            </div>
            <div class="gallery-item-overlay">
                <span class="item-cat">${categoryLabel}</span>
                <h3 class="item-title">${title}</h3>
                <div class="item-meta">
                    <span>${painting.year}</span>
                    <span>${painting.size}</span>
                </div>
            </div>
        `;

        item.addEventListener('click', () => {
            openLightbox(painting.id);
        });

        grid.appendChild(item);
    });
}

function initGalleryFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const filter = btn.getAttribute('data-filter');
            
            // Activar botón en el menú
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            filterGallery(filter);
        });
    });
}

function filterGallery(filter) {
    const items = document.querySelectorAll('.gallery-item');
    
    if (filter === 'todos') {
        state.filteredPaintings = [...PAINTINGS_DATA];
    } else {
        state.filteredPaintings = PAINTINGS_DATA.filter(p => p.category === filter);
    }

    items.forEach(item => {
        const cat = item.getAttribute('data-category');
        if (filter === 'todos' || cat === filter) {
            item.style.display = 'block';
            setTimeout(() => {
                item.style.opacity = '1';
                item.style.transform = 'scale(1)';
            }, 50);
        } else {
            item.style.opacity = '0';
            item.style.transform = 'scale(0.9)';
            setTimeout(() => {
                item.style.display = 'none';
            }, 300);
        }
    });
}

// --- LIGHTBOX / MODAL DE DETALLE DE OBRA ---
function initLightbox() {
    const modal = document.getElementById('art-lightbox');
    const closeBtn = document.getElementById('close-lightbox');
    const prevBtn = document.getElementById('prev-lightbox-btn');
    const nextBtn = document.getElementById('next-lightbox-btn');
    const inquireBtn = document.getElementById('inquire-painting-btn');

    closeBtn.addEventListener('click', closeLightbox);
    
    // Cerrar al hacer clic fuera del contenido
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeLightbox();
        }
    });

    // Navegar en Lightbox
    prevBtn.addEventListener('click', () => {
        navigateLightbox(-1);
    });
    nextBtn.addEventListener('click', () => {
        navigateLightbox(1);
    });

    // Botón consultar obra
    inquireBtn.addEventListener('click', () => {
        const painting = PAINTINGS_DATA.find(p => p.id === state.currentLightboxId);
        if (painting) {
            closeLightbox();
            navigateToSection('contacto');
            
            const lang = state.currentLang;
            const translation = TRANSLATIONS[lang].paintings[painting.id];
            const title = translation ? translation.title : "";
            const tech = translation ? translation.tech : "";
            
            const subjectTemplate = TRANSLATIONS[lang].lightbox.inquireSubject;
            const messageTemplate = TRANSLATIONS[lang].lightbox.inquireMessage;

            const subject = subjectTemplate.replace('{title}', title);
            const message = messageTemplate
                .replace('{title}', title)
                .replace('{year}', painting.year)
                .replace('{tech}', tech)
                .replace('{size}', painting.size);

            // Rellenar automáticamente formulario de contacto
            const subjectField = document.getElementById('form-subject');
            const messageField = document.getElementById('form-message');
            
            if (subjectField) {
                subjectField.value = subject;
                // Simular input para mover la etiqueta en el diseño CSS float
                subjectField.dispatchEvent(new Event('input', { bubbles: true }));
            }
            if (messageField) {
                messageField.value = message;
                messageField.dispatchEvent(new Event('input', { bubbles: true }));
            }

            // Hacer focus al campo de nombre
            setTimeout(() => {
                const nameField = document.getElementById('form-name');
                if (nameField) nameField.focus();
            }, 500);
        }
    });

    // Cerrar con tecla Escape
    document.addEventListener('keydown', (e) => {
        if (modal.classList.contains('active')) {
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowRight') navigateLightbox(1);
            if (e.key === 'ArrowLeft') navigateLightbox(-1);
        }
    });
}

function openLightbox(paintingId) {
    const painting = PAINTINGS_DATA.find(p => p.id === paintingId);
    if (!painting) return;

    state.currentLightboxId = paintingId;

    // Poblar datos e imágenes
    document.getElementById('lightbox-img').src = painting.image;
    updateLightboxTexts(paintingId);

    // Mostrar modal
    const modal = document.getElementById('art-lightbox');
    modal.style.display = 'flex';
    setTimeout(() => {
        modal.classList.add('active');
    }, 50);

    // Desactivar scroll del cuerpo
    document.body.style.overflow = 'hidden';
}

function updateLightboxTexts(paintingId) {
    const painting = PAINTINGS_DATA.find(p => p.id === paintingId);
    if (!painting) return;

    const lang = state.currentLang;
    const translation = TRANSLATIONS[lang].paintings[paintingId];
    const lightboxTrans = TRANSLATIONS[lang].lightbox;

    const title = translation ? translation.title : "";
    const tech = translation ? translation.tech : "";
    const desc = translation ? translation.desc : "";

    document.getElementById('lightbox-img').alt = title;
    
    // Categoría
    const catKey = 'filter' + painting.category.charAt(0).toUpperCase() + painting.category.slice(1);
    document.getElementById('lightbox-cat').textContent = TRANSLATIONS[lang].miObra[catKey];
    
    document.getElementById('lightbox-title').textContent = title;
    document.getElementById('lightbox-year').textContent = painting.year;
    document.getElementById('lightbox-tech').textContent = tech;
    document.getElementById('lightbox-size').textContent = painting.size;
    document.getElementById('lightbox-desc').textContent = desc;

    // Estado de la obra
    const statusVal = document.getElementById('lightbox-status');
    const isAvailable = painting.status === 'Disponible';
    statusVal.textContent = isAvailable ? lightboxTrans.available : lightboxTrans.privateCol;
    statusVal.style.color = isAvailable ? '#81c784' : '#e57373';
}

function closeLightbox() {
    const modal = document.getElementById('art-lightbox');
    modal.classList.remove('active');
    
    setTimeout(() => {
        modal.style.display = 'none';
        // Activar scroll del cuerpo
        document.body.style.overflow = '';
        state.currentLightboxId = null;
    }, 500);
}

function navigateLightbox(direction) {
    // Encontrar índice actual en la lista filtrada para una navegación consistente
    const currentIndex = state.filteredPaintings.findIndex(p => p.id === state.currentLightboxId);
    if (currentIndex === -1) return;

    let nextIndex = currentIndex + direction;
    if (nextIndex >= state.filteredPaintings.length) nextIndex = 0;
    if (nextIndex < 0) nextIndex = state.filteredPaintings.length - 1;

    const nextPainting = state.filteredPaintings[nextIndex];
    
    // Transición visual rápida al cambiar de cuadro en el modal
    const content = document.querySelector('.lightbox-content');
    content.style.transform = 'scale(0.95)';
    content.style.opacity = '0.5';

    setTimeout(() => {
        openLightbox(nextPainting.id);
        content.style.transform = 'scale(1)';
        content.style.opacity = '1';
    }, 150);
}

// --- FORMULARIO DE CONTACTO ---
function initContactForm() {
    const form = document.getElementById('artist-contact-form');
    const statusMsg = document.getElementById('form-status-msg');

    // Añadir manejadores para etiquetas flotantes de textarea/inputs pre-rellenos
    const inputs = form.querySelectorAll('.form-input');
    inputs.forEach(input => {
        input.addEventListener('input', () => {
            if (input.value.trim() !== '') {
                input.placeholder = ' '; // Habilita el CSS selector :not(:placeholder-shown)
            }
        });
    });

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const name = document.getElementById('form-name').value;
        const email = document.getElementById('form-email').value;
        const subject = document.getElementById('form-subject').value;
        const message = document.getElementById('form-message').value;
        
        const lang = state.currentLang;

        // Validaciones básicas
        if (!name || !email || !message) {
            showFormStatus(TRANSLATIONS[lang].contacto.formError, 'error');
            return;
        }

        // Simulación de envío
        const submitBtn = document.getElementById('form-submit-btn');
        submitBtn.disabled = true;
        submitBtn.textContent = TRANSLATIONS[lang].contacto.formSending;

        setTimeout(() => {
            const successTemplate = TRANSLATIONS[lang].contacto.formSuccess;
            const successMsg = successTemplate.replace('{name}', name);
            
            showFormStatus(successMsg, 'success');
            form.reset();
            submitBtn.disabled = false;
            submitBtn.textContent = TRANSLATIONS[lang].contacto.formBtn;
            
            // Eliminar clases flotantes al resetear
            inputs.forEach(i => i.placeholder = ' ');
        }, 1500);
    });

    function showFormStatus(msg, type) {
        statusMsg.textContent = msg;
        statusMsg.className = `form-status ${type}`;
        statusMsg.style.display = 'block';

        // Ocultar mensaje de éxito después de 8 segundos
        if (type === 'success') {
            setTimeout(() => {
                statusMsg.style.opacity = '0';
                setTimeout(() => {
                    statusMsg.style.display = 'none';
                    statusMsg.style.opacity = '1';
                }, 400);
            }, 8000);
        }
    }
}
